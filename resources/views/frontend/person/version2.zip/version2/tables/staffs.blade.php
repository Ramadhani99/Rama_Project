<div class="row">
	<div class="col-md-12">
		<h3>Staffs</h3>		
		<div class="table-responsive">
			<div id = "dvData">
			<table class="table table-bordered table-hover table-striped" id="personTable">
				<thead id="tblHeader">	
				<tr>		  	
					<th>Name</th>
					<th>Date of birth</th>
					<th>Gender</th>
					<th>Type</th>
					<th class="operation">Operations</th>
				</tr>
				</thead>
				<tbody id="tbody_person">
					 

				</tbody>			  	


			</table>
			</div>
		</div>
	</div>
</div>
